import os
import openai

def init_api():
    with open(".env") as env:
        for line in env:
            key, value = line.strip().split("=")
            os.environ[key] = value

    openai.api_key = os.environ.get("API_KEY")
    openai.organization = os.environ.get("ORG_ID")

init_api()

prompt = "Happy Penelopa Cruz smiling and waving at tourists in the Vatican museum, Silver and Crimson, zoom shot, Aperture: f/8, Shutter Speed: 1/15s, ISO: 100, Fine art photography, Kodak Gold 200 film color"
n = 1
size = "512x512"

kwargs = {
    "prompt": prompt,
    "n": n,
    "size": size,
}

im = openai.Image.create(**kwargs)

for i in range(n):
    print(im.data[i].url)
