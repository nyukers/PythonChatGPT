import os
import openai

def init_api():
    with open(".env") as env:
        for line in env:
            key, value = line.strip().split("=")
            os.environ[key] = value
    openai.api_key = os.environ.get("API_KEY")

init_api()

#openai.organization = os.environ.get("ORG_ID")

#response = openai.Edit.create(
#    model="text-davinci-edit-001",
#    instruction="Translate the following sentence to English: 'Hallo Welt'"
#)

#response = openai.Edit.create(
#   model="text-davinci-edit-001",
#   instruction="Translate from English to French and Spanish.",
#   input="The cat sat on the mat."
#)

response = openai.Completion.create(
   model="text-davinci-003",
   prompt="""
   Translate the following sentence from English to French and Spanish.
   English: The black cat hide on the black room.
   """,
   max_tokens=60,
   temperature=0
)

print(response)
#print(response['choices'][0]['text'])

