# Ответ пользователю
def reply(result_queue, verbose):
    while True:
        question = result_queue.get()
        # Мы используем такой формат запроса: «Q: <запрос>?\nA:»
        prompt = "Q: {}?\nA:".format(question)
        data = openai.Completion.create(
            model="text-davinci-002",
            prompt=prompt,
            temperature=0.5,
            max_tokens=100,
            n = 1,
            stop=["\n"]
        )
        # Перехват исключения если нет ответа
        try:
            answer = data["choices"][0]["text"]
            mp3_obj = gTTS(text=answer, lang="en", slow=False)
        except Exception as e:
            choices = ["Извините, у меня нет ответ на этот запрос", "Не уверен что правильно понимаю", "Не уверен, что смогу на это ответить", "Пожалуйста, попробуйте сформулировать запрос иначе"]
            mp3_obj = gTTS(text=choices[np.random.randint(0, len(choices))],
            lang="en", slow=False)
            if verbose:
                print(e)
        # В обоих случаях воспроизводим аудио
        mp3_obj.save("reply.mp3")
        reply_audio = AudioSegment.from_mp3("reply.mp3")
        play(reply_audio)
