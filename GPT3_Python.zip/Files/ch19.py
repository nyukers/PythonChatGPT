import os
import openai

def init_api():
    with open(".env") as env:
        for line in env:
            key, value = line.strip().split("=")
            os.environ[key] = value

    openai.api_key = os.environ.get("API_KEY")
    openai.organization = os.environ.get("ORG_ID")

init_api()

image = open("f:\\111.png", "rb")
n = 2
size = "512x512"

kwargs = {
    "image": image,
    "n": n,
    "size": size
}

response = openai.Image.create_variation(**kwargs)
#url = response

for i in range(n):
    print(response.data[i].url)